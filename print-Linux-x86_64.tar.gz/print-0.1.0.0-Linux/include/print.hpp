#include <string>
#include <fstream>
#include <iostream>

///
///1st print function
///
void print(const std::string& text, std::ostream& out = std::cout);
///
///2nd print function
///
void print(const std::string& text, std::ofstream& out);
